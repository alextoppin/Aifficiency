AIFFICIENCY WEBSITE — PUBLISHING GUIDE
======================================

STEP 1: NETLIFY (free hosting)
-------------------------------
1. Go to netlify.com and create a free account
2. Click "Add new site" → "Deploy manually"
3. Drag and drop the entire folder containing these files
4. Your site will be live instantly at a random netlify URL

STEP 2: CONNECT YOUR DOMAIN (aificciency.com)
----------------------------------------------
1. In Netlify: Site settings → Domain management → Add custom domain
2. Enter: aificciency.com
3. Netlify will give you nameserver addresses (e.g. dns1.p01.nsone.net)
4. Log into your domain registrar and update the nameservers to Netlify's
5. Wait up to 24 hours for DNS to propagate (usually much faster)

STEP 3: FORMSPREE (contact form)
---------------------------------
1. Go to formspree.io and create a free account
2. Create a new form — it will give you a form ID like "xpznkwqr"
3. Open aifficiency-contact.html and replace:
   action="https://formspree.io/f/YOUR_FORM_ID"
   with your actual ID, e.g.:
   action="https://formspree.io/f/xpznkwqr"
4. Re-upload the contact file to Netlify (drag and drop again)

STEP 4: EMAIL
--------------
Set up alex@aificciency.com via your domain registrar or Google Workspace.
The contact page already references this email address.

PAGES
------
index.html              → Homepage (aificciency.com)
aifficiency-why.html    → Why AI page
aifficiency-pricing.html → Services & Pricing
aifficiency-about.html  → About Alex
aifficiency-insights.html → Insights
aifficiency-faq.html    → FAQ
aifficiency-aiready.html → Is AI Right For Me?
aifficiency-contact.html → Contact



UPDATE NOTES
------------
These HTML files are standalone: the CSS has been embedded into each page, so there is no external style.css dependency. Upload the whole folder, or upload individual HTML files as needed.
